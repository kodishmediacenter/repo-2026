
import requests

API_KEY = "AIzaSyD84lBiJDm3Ms0J9Sa8qhJ7Cgd6xUYFfBg"


def obter_canal(handle):
    handle = handle.lstrip("@")

    url = "https://www.googleapis.com/youtube/v3/search"

    params = {
        "part": "snippet",
        "q": "@" + handle,
        "type": "channel",
        "maxResults": 1,
        "key": API_KEY
    }

    r = requests.get(url, params=params)
    r.raise_for_status()
    data = r.json()

    if not data.get("items"):
        return None

    item = data["items"][0]["snippet"]

    return {
        "id": item["channelId"],
        "nome": item["title"],
        "icone": item["thumbnails"]["high"]["url"]
    }

entrada = input("Digite o @handle ou URL do canal: ")

canal = obter_canal(entrada)

if canal:
    name2 = canal["nome"]
    ids2 = canal["id"]
    icon2 = canal["icone"]

    print(f'addDir(title="{name2}", url="plugin://plugin.video.youtube/channel/{ids2}/", thumbnail="{icon2}")')
else:
    print("Canal não encontrado.")