# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
import requests,json
# Plugin Info

ADDON_ID      = 'plugin.video.midianinja'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCwefw3viiiaxprsV6jgJvEA"
icon1 = "https://yt3.googleusercontent.com/ytc/AIdro_ktoKtC4I5tQxT_AlgWWthNzyXxvQRRdmv88eVXFPsS2s0=s256-c-k-c0x00ffffff-no-rj"
ids = YOUTUBE_CHANNEL_ID1
name = "Midia Ninja"

YOUTUBE_CHANNEL_ID2=  "channel/UCe81jbOMWvdZnkqAuy3ea7Q"
icon2 = "https://yt3.googleusercontent.com/zqZ02pFpu9LpeILX9VdsZzF5U9V6yTNpSM0PJGne_8sV6G7Qu3D_Shf3EgTNv97Hvb6BHg7F=s256-c-k-c0x00ffffff-no-rj"
ids2 = YOUTUBE_CHANNEL_ID2
name2 = "Cine Ninja"

def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

if __name__ == '__main__':
   addDir(title = name,url = "plugin://plugin.video.youtube/"+ids+"/",thumbnail = icon1,)
   addDir(title = name2,url = "plugin://plugin.video.youtube/"+ids2+"/",thumbnail = icon2,)
   addDir(title="Poderes Pretos", url="plugin://plugin.video.youtube/channel/UCdeR0R8Eu_rtFOEWX78jEZw/", thumbnail="https://yt3.ggpht.com/klgFA8McIr-XMeJezJMJfa3DBoKHlDTSgbDG0X0hV6wb9Stfio-j-qCbHrz2VLR58bEu80tahGE=s800-c-k-c0xffffffff-no-rj-mo")
   addDir(title="Planeta Ella", url="plugin://plugin.video.youtube/channel/UCS-WDbJXm6PjawOx--iimqQ/", thumbnail="https://yt3.ggpht.com/azadZDbAcN0ZMGd1RLl1NGINF7zq1ZISIa9AsPVjAqYM3k8IloGVS0EswksD7l-bIb3uL-RdSA=s800-c-k-c0xffffffff-no-rj-mo")
   addDir(title="XEPA Cozinha e Ativismo", url="plugin://plugin.video.youtube/channel/UCwv0QjcMwfB3Tmw7PECoETw/", thumbnail="https://yt3.ggpht.com/XcLbC_nzW5-KmfSQfT8OtRu6lS2yy8G77KB6shXql0UWfCmh8akO_C6JE8jJkKie3EGj3epgoqY=s800-c-k-c0xffffffff-no-rj-mo")
   addDir(title="Floresta Ativista", url="plugin://plugin.video.youtube/channel/UCSZqkeQb78fE9nN98L8dq6g/", thumbnail="https://yt3.ggpht.com/cE5Hr0Lu5sidiKRHOTmf-Q_EQ38rOxG9lHTWFWlhPVBvR2c_VaonvBAp7BjLgWUgjuXy4RR52w=s800-c-k-c0xffffffff-no-rj-mo")
   addDir(title="Candinho - Aqui Nasceu o Vasco", url="plugin://plugin.video.youtube/channel/UC6awCfVh6aBYkPAmm7xxLwg/", thumbnail="https://yt3.ggpht.com/tmhrYTofeB6qYHhCS3WptIh_F_Ec8_gAJCXoT9shV3nYf6eHKNLaYlvhmWE_5MSQxuXVBT8p=s800-c-k-c0xffffffff-no-rj-mo")
   addDir(title="NINJA Esporte Clube", url="plugin://plugin.video.youtube/channel/UChznLwi2Sdh37XVHp3mtlog/", thumbnail="https://yt3.ggpht.com/Ff48tVw5TA7FuUWq_l_B5Bl0joCe_FH_wwBfcMlFz77KePCSvL2Q7_1321AgHzcWPxMCqGlD=s800-c-k-c0xffffffff-no-rj-mo")
   addDir(title="Estudantes NINJA", url="plugin://plugin.video.youtube/channel/UCAj7SMSQOoDRchtJ_Ts-sgA/", thumbnail="https://yt3.ggpht.com/G_giZNobbZYAI5G1rX89GBRZSm6UCxp6O84mNRVuPlMhChmQ78hJ72lLywl2QsSnyHxlAxevUsA=s800-c-k-c0xffffffff-no-rj-mo")

   xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
