import subprocess
import xbmcgui 


def twitch(): 
	dialog = xbmcgui.Dialog()
	player = dialog.select('Twitch: ', ['Seguindo','Diretorio','Busca','',''])
	
	if player == 0:
		subprocess.Popen(["flatpak", "run", "com.google.Chrome" , "https://www.twitch.tv/directory/following"])

	if player == 1:
		subprocess.Popen(["flatpak", "run", "com.google.Chrome" , "https://www.twitch.tv/directory"])

	if player == 2:
		termo = xbmcgui.Dialog().input("Digite o Busca", type=xbmcgui.INPUT_ALPHANUM)
		subprocess.Popen(["flatpak", "run", "com.google.Chrome" , "https://www.twitch.tv/search?term="+termo+""])



def menu(): 
	dialog = xbmcgui.Dialog()
	player = dialog.select('Apps Instalados', ['Youtube','Stremio','Radio','Spotify','Twitch'])
	
	if player == 0:
		subprocess.Popen(["flatpak", "run", "rocks.shy.VacuumTube"])
	if player == 1:
                subprocess.Popen(["flatpak", "run", "com.stremio.Stremio"]) 
	if player == 2:
		subprocess.Popen(["sh", "/kodish/scripts/radio.sh"])
	if player == 3:
		subprocess.Popen(["flatpak", "run", "com.spotify.Client"])
	if player == 4:
		twitch()

menu()