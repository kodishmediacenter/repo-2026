# -*- coding: utf-8 -*- 
import sys 
import xbmcaddon, xbmcgui, xbmcplugin 
import requests,json
# Plugin Info

ADDON_ID      = 'plugin.video.hidratuxedo'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1=  "channel/UCZiYbVptd3PVPf4f6eR6UaQ/live"
icon1 = "https://raw.githubusercontent.com/kodishmediacenter/Rework-HidraMX/main/icones/cazetv-logo-0-2048x2048_Easy-Resize.com_.jpg"
icon2 = "https://raw.githubusercontent.com/kodishmediacenter/Rework-HidraMX/refs/heads/main/icones/copa.png"
ids = YOUTUBE_CHANNEL_ID1
name = "Caze TV"
def addDir(title, url, thumbnail):
    liz=xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', 'false')
    liz.setInfo(type="Video", infoLabels={"label":title,"title":title} )
    liz.setArt({'thumb':thumbnail,'fanart':FANART})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=True)

def main():
    addDir(title = " === Copa do Mundo 2026 === ",url = "plugin://plugin.video.youtube/"+ids+"/",thumbnail = icon2)
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
# GRUPO A
    addDir(title = "=== Grupo A ===", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "México x África do Sul", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Coreia do Sul x República Tcheca", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "México x Coreia do Sul", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "África do Sul x República Tcheca", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "México x República Tcheca", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "África do Sul x Coreia do Sul", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

# GRUPO B
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "=== Grupo B === ", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Canadá x Suíça", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Catar x Bósnia e Herzegovina", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Canadá x Catar", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Suíça x Bósnia e Herzegovina", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Canadá x Bósnia e Herzegovina", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Suíça x Catar", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

# GRUPO C
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "=== Grupo C === ", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Brasil x Marrocos", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Escócia x Haiti", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Brasil x Escócia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Marrocos x Haiti", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Brasil x Haiti", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Marrocos x Escócia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

    # GRUPO D
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "=== Grupo D === ", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Estados Unidos x Paraguai", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Austrália x Turquia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Estados Unidos x Austrália", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Paraguai x Turquia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Estados Unidos x Turquia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Paraguai x Austrália", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

    # GRUPO E
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "=== Grupo E === ", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Alemanha x Equador", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Costa do Marfim x Curaçao", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Alemanha x Costa do Marfim", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Equador x Curaçao", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Alemanha x Curaçao", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Equador x Costa do Marfim", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

    # GRUPO F
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "=== Grupo F === ", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Holanda x Japão", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Suécia x Tunísia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Holanda x Suécia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Japão x Tunísia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Holanda x Tunísia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Japão x Suécia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

    # GRUPO G
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "=== Grupo G === ", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Bélgica x Egito", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Irã x Nova Zelândia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Bélgica x Irã", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Egito x Nova Zelândia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Bélgica x Nova Zelândia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Egito x Irã", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

    # GRUPO H
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "=== Grupo H === ", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Espanha x Uruguai", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Arábia Saudita x Cabo Verde", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Espanha x Arábia Saudita", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Uruguai x Cabo Verde", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Espanha x Cabo Verde", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Uruguai x Arábia Saudita", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

    # GRUPO I
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "=== Grupo I === ", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "França x Senegal", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Noruega x Iraque", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "França x Noruega", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Senegal x Iraque", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "França x Iraque", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Senegal x Noruega", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

    # GRUPO J
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "=== Grupo J === ", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Argentina x Áustria", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Argélia x Jordânia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Argentina x Argélia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Áustria x Jordânia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Argentina x Jordânia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Áustria x Argélia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

    # GRUPO K
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "=== Grupo K === ", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Portugal x Colômbia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Uzbequistão x RD Congo", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Portugal x Uzbequistão", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Colômbia x RD Congo", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Portugal x RD Congo", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Colômbia x Uzbequistão", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

    # GRUPO L
    addDir(title = "", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "=== Grupo L === ", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Inglaterra x Croácia", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Gana x Panamá", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Inglaterra x Gana", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Croácia x Panamá", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Inglaterra x Panamá", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)
    addDir(title = "Croácia x Gana", url = "plugin://plugin.video.youtube/"+ids+"/", thumbnail = icon2)

    addDir(title = "===> Play",url = "plugin://plugin.video.youtube/"+ids+"/",thumbnail = icon1,)
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
