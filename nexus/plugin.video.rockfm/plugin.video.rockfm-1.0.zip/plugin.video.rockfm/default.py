# -*- coding: utf-8 -*-
import sys
import xbmcaddon
import xbmcgui
import xbmcplugin

# Informações do Addon
ADDON_ID      = 'plugin.video.rockfm'
REAL_SETTINGS = xbmcaddon.Addon(id=ADDON_ID)
ADDON_NAME    = REAL_SETTINGS.getAddonInfo('name')
ICON          = REAL_SETTINGS.getAddonInfo('icon')
FANART        = REAL_SETTINGS.getAddonInfo('fanart')

YOUTUBE_PLAYLIST = "playlist/PLem8NDDaQ8G0lW16QGbbw6LFIo5qJkhX5"
ICON_URL = "https://yt3.ggpht.com/WnblfjJkwsJePQT2yFwS9_PpgwwALMAL9AA3HIpVe5pNAwgb14OK16Xn_7YF7TmpP9SDc2i9ew=s800-c-k-c0x00ffffff-no-rj"

def addDir(title, url, thumbnail, is_folder=True, is_playable='false'):
    liz = xbmcgui.ListItem(title)
    liz.setProperty('IsPlayable', is_playable)
    liz.setInfo(type="Music" if not is_folder else "Video", infoLabels={"label": title, "title": title})
    liz.setArt({'thumb': thumbnail, 'fanart': FANART, 'icon': ICON})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=liz, isFolder=is_folder)

if __name__ == '__main__':
    # Item 1: Playlist do YouTube
    addDir(
        title="Rock FM Todas Estações Youtube",
        url="plugin://plugin.video.youtube/" + YOUTUBE_PLAYLIST + "/",
        thumbnail=ICON_URL,
        is_folder=True
    )
    
    # Item 2: Rádio Online (Stream de Áudio)
    addDir(
        title="Radio Online",
        url="https://rockfm.rockfm.com.tr:9450/stream",
        thumbnail=ICON_URL,
        is_folder=False,
        is_playable='true'
    )
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=True)